package eCommerceSim.core;

public interface AuthServiceAdapter {
}
