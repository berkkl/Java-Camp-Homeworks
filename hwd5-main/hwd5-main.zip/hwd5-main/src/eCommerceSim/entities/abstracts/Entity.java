package eCommerceSim.entities.abstracts;

public interface Entity {
}
